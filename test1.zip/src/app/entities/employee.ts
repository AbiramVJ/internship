import {Gender} from "./gender";

export class Employee{
  id?: number;
  name?: string;
  age?: number;
  nic?: string;
  gender?: Gender;


}
